const HDWalletProvider = require('@truffle/hdwallet-provider');
const { Web3 } = require('web3');
const contractJSON = require('./build/contracts/FileStorage.json');

// 1. CONFIGURATION
const mnemonic = "kangaroo into young parade draft half similar random quality remember screen usual"; 
const rpcUrl = "http://127.0.0.1:7545";

async function runWallet() {
    console.log(" Initializing HD Wallet...");

    // Setup Provider & Web3 بيطلع private , puplic , address of wallet
    const provider = new HDWalletProvider(mnemonic, rpcUrl);
    const web3 = new Web3(provider); // to sign need provider

    try {
        const accounts = await web3.eth.getAccounts();
        const walletAddress = accounts[0];
        console.log(`✅ Wallet Recovered: ${walletAddress}`);

        const networkId = await web3.eth.net.getId();
        const deployedNetwork = contractJSON.networks[networkId];
        const contract = new web3.eth.Contract(contractJSON.abi, deployedNetwork.address);

        // --- STEP 1: YOUR SPECIFIC DATA ---
        const myHash = "QmVZewHpDfkrfqVELNksDfbM42buwWrfjzAMJsBHkmZCug"; 
        const myName = "moresa was here.txt";

        // --- STEP 2: UPLOAD ---
        console.log("------------------------------------------------");
        console.log(`📝 Signing Transaction for: "${myName}"`);
        console.log(`🔗 Hash: ${myHash}`);
        
        await contract.methods.uploadFile(myHash, myName).send({
            from: walletAddress,
            gas: 300000
        });
        
        console.log("✅ Transaction SUCCESSFUL! (Data saved to Blockchain)");

        // --- STEP 3: PROVE IT (Fixed BigInt Error) ---
        console.log("------------------------------------------------");
        console.log("🔎 VERIFYING DATA...");
        
        // Get the total count (Returns a BigInt like 5n)
        const count = await contract.methods.getFilesCount(walletAddress).call();
        
        // FIX: Convert BigInt to a normal Number before subtracting
        const index = Number(count) - 1;
        
        // Get the very last file
        const lastFile = await contract.methods.getFile(walletAddress, index).call();

        console.log(`📂 READ FROM CHAIN:  ${lastFile[1]}`); // Name
        console.log(`🔗 READ FROM CHAIN:  ${lastFile[0]}`); // Hash
        console.log("------------------------------------------------");

        if (lastFile[1] === "moresa was here.txt") {
            console.log(" SUCCESS: 'moresa was here.txt' is permanently stored!");
        }

    } catch (error) {
        console.error("❌ Error:", error.message);
    } finally {
        provider.engine.stop();
    }
}

runWallet();