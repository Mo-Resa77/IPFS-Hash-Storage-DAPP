// here should be the test and debug js
 code ... but due to time i didn't make it 